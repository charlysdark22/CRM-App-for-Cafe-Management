
  # CRM App for Cafe Management

  This is a code bundle for CRM App for Cafe Management. The original project is available at https://www.figma.com/design/U7hU2Sm8zvqIBXadynChvy/CRM-App-for-Cafe-Management.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  